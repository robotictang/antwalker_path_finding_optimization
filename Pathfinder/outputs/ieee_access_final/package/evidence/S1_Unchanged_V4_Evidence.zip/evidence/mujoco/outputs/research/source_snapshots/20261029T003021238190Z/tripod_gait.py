"""Ground-referenced tripod gait with planted stance feet and smooth swing IK.

The mission preview retains assisted chassis velocity/attitude control. This gait
is not a balance controller or proof of torque-feasible hardware locomotion.
"""
import math
import numpy as np
from road_demo import ground_height


class TripodGait:
    def __init__(self, period=1/1.45, duty=.60, lift=.13, swing_profile='quintic'):
        if not (.3 <= period <= 2.0 and .5 <= duty <= .85 and .04 <= lift <= .3):
            raise ValueError('Gait requires period 0.3..2 s, duty 0.5..0.85, lift 0.04..0.3 m')
        if swing_profile not in ('quintic', 'cubic'):
            raise ValueError('Unknown swing profile')
        self.period, self.duty, self.lift = float(period), float(duty), float(lift)
        self.swing_profile = swing_profile
        self.time = 0.0
        self.feet = None
        self.swing_start = np.zeros((6,3))
        self.swing_end = np.zeros((6,3))
        self.was_swing = np.zeros(6,dtype=bool)
        self.hips = np.array([[.32,.41],[0,.41],[-.32,.41],[.32,-.41],[0,-.41],[-.32,-.41]])
        self.home = np.array([[.73,1.26],[0,1.45],[-.73,1.26],[.73,-1.26],[0,-1.45],[-.73,-1.26]])
        self.phase = np.array([0,.5,0,.5,0,.5])

    def reset(self):
        self.feet = None
        self.was_swing[:] = False
        self.time = 0.0

    def targets(self, xy, yaw, height, speed, omega, dt=.016, actual_feet=None):
        rotation = np.array([[math.cos(yaw),-math.sin(yaw)],[math.sin(yaw),math.cos(yaw)]])
        home_world = self.home @ rotation.T + xy
        if self.feet is None:
            self.feet = np.column_stack([home_world,ground_height(home_world,radius=.10)+.055])
        moving = abs(speed)>.005 or abs(omega)>.005
        # Finish any swing already started before settling at rest.
        if moving or self.was_swing.any():
            self.time += dt
        frequency, duty = 1/self.period, self.duty
        poses=[]
        for i in range(6):
            phi=(self.time*frequency+self.phase[i])%1
            swing=phi>=duty and (moving or self.was_swing[i])
            if swing:
                if not self.was_swing[i]:
                    self.swing_start[i]=self.feet[i]
                    horizon=.5/frequency
                    future_yaw=yaw+omega*horizon
                    r=np.array([[math.cos(future_yaw),-math.sin(future_yaw)],[math.sin(future_yaw),math.cos(future_yaw)]])
                    future_xy=xy+speed*horizon*np.array([math.cos(yaw),math.sin(yaw)])
                    self.swing_end[i,:2]=future_xy+r@self.home[i]
                    self.swing_end[i,2]=.055+float(ground_height(self.swing_end[i,:2],radius=.10))
                u=(phi-duty)/(1-duty)
                ease=u**3*(10+u*(-15+6*u)) if self.swing_profile=='quintic' else u*u*(3-2*u)
                self.feet[i]=(1-ease)*self.swing_start[i]+ease*self.swing_end[i]
                self.feet[i,2]+=self.lift*math.sin(math.pi*u)**2
            elif self.was_swing[i]:
                self.feet[i]=self.swing_end[i]
            # Anticipate a foot-sized contact patch before crossing a raised edge.
            support=float(ground_height(self.feet[i,:2],radius=.10))
            if actual_feet is not None:support=max(support,float(ground_height(actual_feet[i,:2],radius=.10)))
            self.feet[i,2]=max(self.feet[i,2],.055+support)
            self.was_swing[i]=swing
            local=(self.feet[i,:2]-xy)@rotation-self.hips[i]
            if i>=3:
                local=-local
            radial=np.linalg.norm(local)-.157
            z=self.feet[i,2]-height-.1085
            knee=-math.acos(float(np.clip((radial**2+z**2-.700**2-.764**2)/(2*.700*.764),-1,1)))
            femur=math.atan2(z,radial)-math.atan2(.764*math.sin(knee),.700+.764*math.cos(knee))
            hip=math.atan2(-local[0],local[1])
            poses.extend([np.clip(hip,-.785,.785),np.clip(femur,-1.047,1.047),np.clip(knee,-2.094,.349)])
        return np.array(poses)


def clear_transform_feet(pose, body_height, ground_level=0.):
    """Keep folded/deploying feet above the ground during assisted morphing."""
    safe = np.asarray(pose).copy()
    for i in range(6):
        femur, knee = safe[3*i+1:3*i+3]
        minimum_sine = (.053+ground_level-body_height-.1085-.700*math.sin(femur))/.764
        lower_knee = math.asin(float(np.clip(minimum_sine,-1,1)))-femur
        safe[3*i+2] = max(knee,lower_knee)
    return safe
