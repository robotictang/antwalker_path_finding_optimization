"""Local button controls and live route comparison, independent of viewer shortcuts."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import json,threading
from urllib.parse import urlparse,parse_qs

KEYS={'place1':321,'place2':322,'place3':323,'place4':324,'charge':320,
      'route':325,'camera':326,'transform':327,'auto':328,'battery':329,'cancel':330,
      'shortest':400,'fastest':401,'reset':402,'energy':403,'balanced':404,'energy_demo':405}
KEY_NAMES={f'KP{i}':320+i for i in range(10)}|{'KP_DECIMAL':330,'SHORTEST':400,'FASTEST':401,'ENERGY':403,'BALANCED':404}


def key_code(value):
    if isinstance(value,int):return value
    value=str(value).upper()
    if value in KEY_NAMES:return KEY_NAMES[value]
    raise ValueError('Use KP0..KP9, KP_DECIMAL, SHORTEST, or FASTEST for scripted commands')


class ControlPanel:
    def __init__(self,commands,port=8767,history=None):
        self.state={};self.lock=threading.Lock()
        outer=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                url=urlparse(self.path);query=parse_qs(url.query)
                if url.path=='/history' and history is not None:
                    try:payload=json.dumps(history.page(before=query.get('before',[None])[0],limit=query.get('limit',[50])[0],category=query.get('category',['all'])[0],after=query.get('after',[None])[0])).encode()
                    except (ValueError,TypeError):self.send_error(400);return
                    kind='application/json'
                elif url.path=='/history.csv' and history is not None:
                    payload=history.csv();kind='text/csv'
                elif self.path=='/state':
                    with outer.lock:payload=json.dumps(outer.state).encode()
                    kind='application/json'
                elif self.path in ('/','/index.html'):
                    payload=(Path(__file__).parent/'mission_control.html').read_bytes();kind='text/html'
                else:self.send_error(404);return
                self.send_response(200);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(payload)
            def do_POST(self):
                if self.path!='/command':self.send_error(404);return
                try:
                    if int(self.headers.get('Content-Length',0))>1000:raise ValueError()
                    body=json.loads(self.rfile.read(int(self.headers.get('Content-Length',0))))
                    action=body['action']
                    if action=='lab_choice':
                        from energy_model import normalize_weights
                        commands.put(dict(lab_choice=dict(comparison_id=str(body['comparison_id']),weights=normalize_weights(body['weights']).tolist())))
                    elif action=='lab':
                        weights=body.get('weights',[1.,1.,1.])
                        from energy_model import normalize_weights
                        commands.put(dict(lab=dict(origin=str(body.get('origin','origin')),destination=int(body.get('destination',1)),weights=normalize_weights(weights).tolist())))
                    elif action=='destination':
                        from multi_place_config import MISSION_TARGETS
                        target=int(body['destination'])
                        if target not in range(len(MISSION_TARGETS)):raise ValueError()
                        commands.put(dict(destination=target))
                    elif action=='weights':
                        from energy_model import normalize_weights
                        commands.put(dict(weights=normalize_weights(body['weights']).tolist()))
                    else:commands.put(KEYS[action])
                except (ValueError,KeyError,TypeError):self.send_error(400);return
                self.send_response(204);self.end_headers()
        self.server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
        print(f'MISSION CONTROL: http://127.0.0.1:{port}',flush=True)

    def update(self,state):
        with self.lock:self.state=state

    def close(self):self.server.shutdown();self.server.server_close()
